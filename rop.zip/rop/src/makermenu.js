const makermenu = (prefix) => { 
	return `═✪〘 🛡Makermenu🛡 〙✪══
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}tahta* [Lindy]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}pronlogo* [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}snowrite┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}marvelogo┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}textdark┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}textblue┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}text3d┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}ninjalogo┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}wolflogo┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}lionlogo┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}textscreen┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}rtext┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}thunder┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}stiltext┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text|text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}party┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}galaxtext┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}lovemake┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}walpaperhd┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}watercolor┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}quotemaker┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [tx|tx|random]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}water┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
╠➥ ┊ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}epep┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
└   ╰ *𖥨ํ∘̥⃟⸽⃟🌺▸*${prefix}glitch┊ *𖥨ํ∘̥⃟⸽⃟🌺▸ [text]
`

}
exports.makermenu = makermenu
