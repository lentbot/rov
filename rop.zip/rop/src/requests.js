const requests = (prefix) => { 
	return `Jika Ingin Meng requests Vitur Bot
1.Tulisan Yg sopan pasti kami Merespon nya
2.Tidak Boleh Berkata kasar kami tidak akan meresponya
3.Gunakan Vitur Dengan Bijak
4. Vitur 18+ (Kami Akan Disable Karna Merugikan)
5.DLl Jika Ingin Requests Ketik $viturquests

Thanks!`

}
exports.requests = requests
