const vituranime = (prefix) => { 
	return `                 
_*>XPTN BOT<*_                
 
 Hi, _*undefined*_ 
 Berikut adalah fitur pada bot!
_*Wibu*_
├ *${prefix}randomanime*
├ *${prefix}waifu*
├ *${prefix}waifu2*
├ *${prefix}nakonime*
├ *${prefix}wibu*
├ *${prefix}wait*
├ *${prefix}inu*
├ *${prefix}pokemon*
├ *${prefix}naruto*
├ *${prefix}hinata*
├ *${prefix}sasuke*
├ *${prefix}sakura*
├ *${prefix}boruto*
├ *${prefix}minato*
├ *${prefix}loli*
├ *${prefix}loli2*
├ *${prefix}rize*
├ *${prefix}akira*
├ *${prefix}itori*
├ *${prefix}kurumi*
└ *${prefix}miku*
╽
╰╼ Ketik *${prefix}info* untuk melihat list informasi tentang bot
       Ketik *${prefix}owner* untuk melihat kontak owner
         Mau donasi? 089655478810(Tri)
         Jika tidak ingin donasi bantu Follow Ig aja kak 
         _instagram.com/_xptn
    _*XPTNBOT © 2020*_`
}
exports.vituranime = vituranime
