const ownermenu = (prefix) => { 
	return `══✪〘 OWNER 〙✪══
•├❍ *${prefix}clearall*
•├❍ *${prefix}block*
•├❍ *${prefix}bc*
•├❍ *${prefix}block 62858xxxxx*
•├❍ *${prefix}unblock 62858xxxxx*
•├❍ *${prefix}promote @tagmember*
•├❍ *${prefix}demote @tagadmin*
•├❍ *${prefix}leave*
•├❍  *${prefix}bc2*
•├❍  *${prefix}leave*
•├❍  *${prefix}clearall*
•├❍  *${prefix}clone*
•├❍  *${prefix}hidetag*
•├❍  *${prefix}hidetag2*
•├❍  *${prefix}setprefix*
•├❍  *${prefix}unban*
•├❍  *${prefix}ban*
•├❍  *${prefix}getses*
 ╚═〘 XPTN BOT 〙
`

}
exports.ownermenu = ownermenu
