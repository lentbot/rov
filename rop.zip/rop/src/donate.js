const donate = (prefix) => { 
	return `                 
_*>XPTN BOT<*_                
 
 Hi, _*All*_ 
 Berikut adalah fitur pada bot!
_*Donate*_
├ Mau donasi ya om?✨
├ اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّب
├jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit)
├Jika kamu tidak punya, maka bisa dengan kalimah thayyibah
├HR. Bukhari 6539, Muslim 1016
├*Pulsa tri :* _0896-5547-8810_\n*Dana :* _0896-5547-8810_\n*Saweria :* _https://saweria.co/agung1\n*Gopay :* _belum tersedia_
├
╰╼ Ketik *${prefix}info* untuk melihat list informasi tentang bot
       Ketik *${prefix}creator* untuk melihat kontak owner
         Mau donasi? 089655478810(Tri)
         Jika tidak ingin donasi bantu Follow Ig aja kak 
         _instagram.com/_xptn
    _*XPTNBOT © 2020*_`
}
exports.donate = donate
